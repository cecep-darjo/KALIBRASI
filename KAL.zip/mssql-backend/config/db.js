import sql from 'mssql';
import 'dotenv/config';

// Konfigurasi sambungan langsung menggunakan Windows Authentication atau Server/Instance
const config = {
  server: '10.14.1.81\\SQLTESTO', // Alamat IP Server dan Instance Anda
  database: 'DbKalibrasi',         // Nama database yang telah anda buat
  options: {
    trustedConnection: true,      // Menggunakan Windows Authentication yang sedang aktif[cite: 5]
    trustServerCertificate: true, // Wajib true untuk persekitaran tempatan/internal
    encrypt: false,               // Set false jika tidak menggunakan SSL/TLS
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
};

let pool: sql.ConnectionPool;

export async function getPool(): Promise<sql.ConnectionPool> {
  if (!pool || !pool.connected) {
    pool = await sql.connect(config);
    console.log('[db] Berjaya disambungkan ke Microsoft SQL Server menggunakan Windows Authentication');
  }
  return pool;
}

export async function query<T extends Record<string, unknown> = Record<string, unknown>>(
  text: string,
  params?: Record<string, unknown>
): Promise<T[]> {
  const p = await getPool();
  const request = p.request();
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      request.input(key, value as sql.ISqlType);
    }
  }
  const result = await request.query(text);
  return result.recordset as T[];
}

export async function queryOne<T extends Record<string, unknown> = Record<string, unknown>>(
  text: string,
  params?: Record<string, unknown>
): Promise<T | undefined> {
  const rows = await query<T>(text, params);
  return rows[0];
}

export { sql };